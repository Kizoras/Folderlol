
<?php $__env->startSection('name'); ?>
    <h3>Laporan Nilai <?php echo e($siswa->nama_siswa); ?></h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<center>
    <table align="center" cellspacing="0" class="table-show">
        <tr>
            <td>Nama Siswa</td>
            <td>:</td>
            <td><?php echo e($siswa->nama_siswa); ?></td>
        </tr>
        <tr>
            <td>Nomor Induk Siswa</td>
            <td>:</td>
            <td><?php echo e($siswa->nis); ?></td>
        </tr>
        <tr>
            <td>Nama Walas</td>
            <td>:</td>
            <td><?php echo e($walas?->nama_walas ?? 'Walas tidak tersedia'); ?></td>
        </tr>

        <tr>
            <td>Kelas</td>
            <td>:</td>
            <td><?php echo e($siswa->kelas->nama_kelas); ?></td>
        </tr>
    </table>
    <table class="table-show table-view">
        <thead>
            <tr>
                <th class="border-head">No</th>
                <th class="border-head">Mata Pelajaran</th>
                <th class="border-head">Nilai</th>
                <th class="border-head">Grade</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="border-data">1</td>
                <td class="border-data">Matematika</td>
                <td class="border-data"><?php echo e($data_nilai['matematika']['nilai']); ?></td>
                <td class="border-data"><?php echo e($data_nilai['matematika']['grade']); ?></td>
            </tr>
            <tr>
                <td class="border-data">2</td>
                <td class="border-data">Bahasa Indonesia</td>
                <td class="border-data"><?php echo e($data_nilai['indonesia']['nilai']); ?></td>
                <td class="border-data"><?php echo e($data_nilai['indonesia']['grade']); ?></td>
            </tr>
            <tr>
                <td class="border-data">3</td>
                <td class="border-data">Bahasa Inggris</td>
                <td class="border-data"><?php echo e($data_nilai['inggris']['nilai']); ?></td>
                <td class="border-data"><?php echo e($data_nilai['inggris']['grade']); ?></td>
            </tr>
            <tr>
                <td class="border-data">4</td>
                <td class="border-data">Konsentrasi Keahlian</td>
                <td class="border-data"><?php echo e($data_nilai['kejuruan']['nilai']); ?></td>
                <td class="border-data"><?php echo e($data_nilai['kejuruan']['grade']); ?></td>
            </tr>
            <tr>
                <td class="border-data">5</td>
                <td class="border-data">Mata Pelajaran Pilihan</td>
                <td class="border-data"><?php echo e($data_nilai['pilihan']['nilai']); ?></td>
                <td class="border-data"><?php echo e($data_nilai['pilihan']['grade']); ?></td>
            </tr>
            <tr>
                <td class="border-data"></td>
                <td class="border-data">Rata - rata</td>
                <td class="border-data"><?php echo e($data_nilai['rata_rata']['nilai']); ?></td>
                <td class="border-data"><?php echo e($data_nilai['rata_rata']['grade']); ?></td>
            </tr>
        </tbody>
    </table>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\www\test1\resources\views/nilai/show.blade.php ENDPATH**/ ?>