
<?php $__env->startSection('name'); ?>
    <h3>Edit Nilai <?php echo e($siswa->nama_siswa); ?></h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if( session('error')): ?>
    <p class="text-danger"><?php echo e(session ('error')); ?></p>
    <?php endif; ?>

    <form class="form" action="/nilai-raport/update/<?php echo e($nilai->id); ?>" method="post">
        <?php echo method_field('put'); ?>
        <?php echo csrf_field(); ?>

        <table>
            <tr class="position">
                <td>
                    <label for="siswa_id">Nama Siswa:</label>
                </td>
                <td>
                    <input value="<?php echo e($siswa->id); ?>" type="hidden" name="siswa_id" id="siswa_id" step="0.01" required>
                    <input value="<?php echo e($siswa->nama_siswa); ?>" type="text" step="0.01" readonly>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="matematika">Matematika:</label>
                </td>
                <td>
                    <input value="<?php echo e($nilai->matematika); ?>" type="number" name="matematika" id="matematika" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="indonesia">Indonesia:</label>
                </td>
                <td>
                    <input value="<?php echo e($nilai->indonesia); ?>" type="number" name="indonesia" id="indonesia" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="inggris">Inggris:</label>
                </td>
                <td>
                    <input value="<?php echo e($nilai->inggris); ?>" type="number" name="inggris" id="inggris" step="0.01" required>
                </td>
            </tr>
            <tr class="position">
                <td>
                    <label for="kejuruan">Kejuruan:</label>
                </td>
                <td>
                    <input value="<?php echo e($nilai->kejuruan); ?>" type="number" name="kejuruan" id="kejuruan" step="0.01" required>
                </td>
            </tr>
            <tr>
                <td>
                    <label for="pilihan">Pilihan:</label>
                </td>
                <td>
                    <input value="<?php echo e($nilai->pilihan); ?>" type="number" name="pilihan" id="pilihan" step="0.01" required>
                </td>
            </tr>
        </table>
        <button class="button-submit" type="submit">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\www\test1\resources\views/nilai/edit.blade.php ENDPATH**/ ?>