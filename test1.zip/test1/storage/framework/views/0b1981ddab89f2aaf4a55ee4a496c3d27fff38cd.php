<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Welcome</h1>
</body>
</html><?php /**PATH C:\Users\RPL\Desktop\soal-lsp-2025-april\LSP 2024\lsp-eraport_nama\resources\views/welcome.blade.php ENDPATH**/ ?>