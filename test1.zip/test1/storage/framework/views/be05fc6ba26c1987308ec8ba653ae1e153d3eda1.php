<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <script src="<?php echo e(asset('assets/js/script.js')); ?>" defer></script>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="<?php echo e(asset('assets/img/smkn1cibinong.png')); ?>" alt="logo">
        </div>

        <div class="form-container">
            <div class="tab">
                <button class="tablinks active" onclick="openTab(event, 'Student')" id="defaultOpen">Login Siswa
                </button>
                <button class="tablinks active" onclick="openTab(event, 'Teacher')">Login Walas
                </button>
            </div>

            <div id="Student" class="tabcontent" style="display: block;">
                <h2>Login Siswa</h2>
                <h3><?php echo e(session('error')); ?></h3>
                <form action="/login-siswa" method="POST">
                    <?php echo csrf_field(); ?>

                    <label for="txt_nis">NISN :</label>
                    <input type="text" id="txt_nis" name="txt_nis" placeholder="Masukkan NIS" required>

                    <label for="txt_pass_siswa">PASSWORD :</label>
                    <input type="password" id="txt_pass_siswa" name="txt_pass" placeholder="Masukkan Password" required>
                    <button type="submit">Login</button>
                </form>
            </div>

            <div id="Teacher" class="tabcontent" style="display: none;">
                <h2>Login Walas</h2>
                <h3><?php echo e(session('error')); ?></h3>
                <form action="/login-walas" method="POST">
                    <?php echo csrf_field(); ?>

                    <label for="txt_nig">NIG :</label>
                    <input type="text" id="txt_nig" name="txt_nig" placeholder="Masukkan NIG:" required>

                    <label for="txt_pass_walas">PASSWORD :</label>
                    <input type="password" id="txt_pass_walas" name="txt_pass" placeholder="Masukkan Password" required>
                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\laragon2\www\test1\resources\views/nilai/login.blade.php ENDPATH**/ ?>