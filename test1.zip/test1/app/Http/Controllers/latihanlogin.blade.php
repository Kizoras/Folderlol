<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\Walas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class loginController extends Controller
{
    public function index(){
        return view('nilai.login');
    }

    public function loginWalas(Request $request)
    {
        $walas = Walas::where('nig', $request->txt_nig)->first();
        if (!$walas || !Hash::check($request->txt_pass, $walas->password)){
            return redirect()->back()->with('error', 'NIG atau password salah!');
        }

        $kelas = Kelas::where('id', $walas->kelas_id)->first();

        session([
            'role'=> 'Walas',
            'id'=> $walas->id,
        ])
    }
}