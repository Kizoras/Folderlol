<?php

namespace App\Http\Controllers;

use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\Walas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class loginController extends Controller
{
    public function index(){
        return view('nilai.login');
    }

    public function loginWalas(Request $request)
    {
        $walas = Walas::where('nig', $request->txt_nig)->first();
        if (!$walas || !Hash::check($request->txt_pass, $walas->password)){
            return redirect()->back()->with('error', 'NIG atau password salah!');
        }

        $kelas = Kelas::where('id', $walas->kelas_id)->first();
        
        session([
            'role' => 'Walas',
            'id' => $walas->id,
            'nig' => $walas->nig,
            'nama' => $walas->nama_walas,
            'kelas_id' => $walas->kelas_id,
            'nama_kelas' => $kelas ? $kelas->nama_kelas : 'Kelas belum di tentukan',
        ]);
        return redirect('nilai-raport/index');
    }

    public function loginSiswa(Request $request)
    {
        $siswa = Siswa::where('nis', $request->txt_nis);
        if (!$siswa || !Hash::check($request->txt_pass, $siswa->password)){
            return redirect()->back()->with('error', 'NIS atau password salah');
        }

        $kelas = Kelas::find($siswa->kelas_id);

        session([
            'role' => 'Siswa',
            'id' => $siswa->id,
            'nis' => $siswa->nis,
            'nama' => $siswa->nama_siswa,
            'kelas_id' => $siswa->kelas_id,
            'nama_kelas' => $kelas ? $kelas->nama_kelas : 'Kelas belum di temukan', 
        ]);
        return redirect('nilai-raport/show');
    }

    public function logout(){
        session()->flush();
        return redirect('/');
    }
}